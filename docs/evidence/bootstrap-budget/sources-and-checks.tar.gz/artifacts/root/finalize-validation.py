import hashlib
import json
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'

def bind(p):
    data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def read(name):
    return json.loads((A / name).read_text())

current = read('source-final.json')['source_sha256']
parent = read('source-parent.json')['source_sha256']
for path, digest in current.items():
    assert bind(W / path)['sha256'] == digest, path
changed = sorted(path for path, digest in current.items() if parent.get(path) != digest)
assert len(changed) == 11 and len(current) == 1675
rust = read('root/rust-validation.json')
assert rust['status'] == 'complete' and rust['new_test_groups'] == 1
strict = []
for label in ['format-check-1', 'default-clippy-1', 'host-vulkan-clippy-1']:
    receipt = A / 'validation' / (label + '.json')
    log = A / 'validation' / (label + '.log')
    result = json.loads(receipt.read_text())
    assert result['exit'] == 0 and result['sha256'] == bind(log)['sha256']
    strict.append(dict(receipt=bind(receipt), log=bind(log)))
replay = read('root/replay-validation.json')
assert replay['status'] == 'pass' and replay['exact_cases'] == 1050 and replay['exact_controls'] == 348
ledger = dict(
    status='pass', base=read('source-parent.json')['base'],
    scope='Separate finite trusted initialization allowance from unchanged author execution allowance.',
    source=bind(A / 'source-final.json'), selected_source_inputs=1675,
    changed_source_paths=changed, production_paths=1, existing_test_migration_paths=10,
    existing_migration_groups=12, new_test_groups=1,
    budgets=dict(bootstrap=1_000_000, author=100_000, cumulative_heap=8*1024*1024),
    startup=dict(consumed_work=99694, raw_remaining=900306, public_remaining=100000,
                 accounted_heap_delta=0, metadata_object_delta=0),
    startup_observation=read('root/candidate-observation-1.json'),
    source_reviews=[bind(A / 'current-source-review-1/source-review.json'),
                    bind(A / 'policy-doc-review-1/source-review.json'),
                    bind(A / 'html-census-review-1/review.json')],
    parent_control=read('root/parent-validation.json'),
    default_passed=3132, host_vulkan_passed=3486,
    roster_validation=bind(A / 'root/rust-validation.json'), strict_checks=strict,
    release_binary=replay['binary'], replay_validation=bind(A / 'root/replay-validation.json'),
    exact_case_records=1050, exact_harness_records=348, baseline_changes=0,
    qualifications=[
        'The original selection rationale no host reads was overbroad: initialization obtains Instant::now for performance_origin. The separate correction is retained. No author callback, document input or Date clock/timezone discovery occurs in initialization.',
        'The parent control stops at its first raw-allowance assertion; its later work/debit/state checks were not executed on the parent.',
        'The 99693/99694/100000 injected initialization matrices remain byte-exact; initialization work and logical allocation consumption have not changed.',
        'No new local Python suite run: tooling, corpora and baselines remain byte-identical; all four existing Promise release profiles were replayed.',
        'Selected source inventory is not the full build graph. Logical work and heap accounting are not CPU or allocator RSS measurements.'
    ],
    limitations=['No new web API, complete compatibility, production-security or Chromium-relative performance claim.',
                 'No GPU implementation change or new acquired-window observation.',
                 'AggregateError and Promise.any remain separate future changes.'])
(A / 'root/final-validation.json').write_text(json.dumps(ledger, indent=2) + '\n')
print('Validation ledger sealed:3132/3486 tests;1050 cases and348 controls exact.')
