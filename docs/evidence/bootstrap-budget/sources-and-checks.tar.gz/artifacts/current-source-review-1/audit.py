from pathlib import Path
import hashlib,json,subprocess,re
P=Path('/tmp/eris-bootstrap-budget-plan-1');W=P/'worktree';R=P/'current-source-review-1'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
parent=json.loads((P/'source-parent.json').read_text())
candidate=json.loads((P/'source-candidate-1.json').read_text())
pm=parent['source_sha256'];cm=candidate['source_sha256']
assert parent['base']==candidate['base']=='15226307b153da0857f80486d5f23c375b6b2add'
assert pm.keys()==cm.keys() and len(pm)==1675
production=json.loads((P/'production-1/source-ready.json').read_text())
control=json.loads((P/'parent-controls-1/source-ready.json').read_text())
selected=(P/'parent-controls-1/selected-test.rs').read_bytes()
expected={}
for row in production['files']:
 rel=row['relative']; before=Path(row['before']['path']).read_bytes(); raw=Path(row['raw']['path']).read_bytes()
 assert sha(before)==row['before']['sha256']==pm[rel]
 assert sha(raw)==row['raw']['sha256']
 if rel=='src/script/bootstrap_tests.rs':
  assert before==Path(control['files'][0]['before']['path']).read_bytes()
  raw+=b'\n'+selected
 expected[rel]=raw
 assert sha(raw)==cm[rel],rel
changed=sorted(rel for rel in pm if pm[rel]!=cm[rel])
assert changed==sorted(expected) and len(changed)==11
for rel,h in cm.items():assert sha((W/rel).read_bytes())==h,rel
status=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=W,text=True)
status_rows=status.splitlines()
assert sorted(row[3:] for row in status_rows)==changed,status
s=(W/'src/script.rs').read_text()
b=(P/'production-1/before/src/script.rs').read_text()
old_const='const MAX_STEPS: usize = 100_000;\n'
new_const=old_const+'// Fixed intrinsic initialization has a separate finite work allowance.\n// Successful public construction resets author work to MAX_STEPS.\nconst BOOTSTRAP_STEPS: usize = 1_000_000;\n'
assert s.count(new_const)==1 and s.count('BOOTSTRAP_STEPS')==2
inverse=s.replace(new_const,old_const,1).replace('            steps: BOOTSTRAP_STEPS,\n','            steps: MAX_STEPS,\n',1)
assert inverse==b
assert 'let mut runtime = Self::uninitialized();\n        runtime.initialize_bootstrap()?;\n        runtime.steps = MAX_STEPS;\n        Ok(runtime)' in s
census=json.loads((P/'migration-census.json').read_text())
matrices=[]
for row in census['unchanged_explicit_allowances']:
 rel=row['path'];x=(W/rel).read_bytes()
 assert sha(x)==pm[rel]==cm[rel]
 assert x==(P/'source-snapshots'/rel).read_bytes()
 matrices.append(dict(relative=rel,group=row['group'],sha256=sha(x)))
qual=json.loads((P/'root/selection-qualification-1.json').read_text())
report=dict(status='clear_current_source_only',reviewer='/root/script',base=parent['base'],inputs=[bind(P/p) for p in ['source-parent.json','source-candidate-1.json','root/source-import-1.json','root/selection-1.json','root/selection-qualification-1.json','production-1/source-ready.json','parent-controls-1/source-ready.json','parent-controls-1/script-review.json']],source_inputs_verified=1675,changed_paths=changed,composition='Ten raw migration files and src/script.rs match production-1 byte-exact, except bootstrap_tests.rs is its migrated raw plus one LF and the exact839-byte parent control. No formatting delta.',unchanged_explicit_matrices=matrices,checks=['Parent and candidate inventory key sets are identical; all1675 candidate file hashes were independently checked against live bytes.', 'Exact eleven-file changed set matches Git porcelain; no extra tracked or untracked source edits were present at review.', 'Two-site production inverse recovers full published script.rs; public success-only reset, Runtime fields/layout/identities, all fees/caps and heap expressions outside those sites are untouched.', 'All twelve old-group changes come from frozen migration census; exactly one separately authored parent control is appended.', 'Three injected99693/99694/100000 matrices remain byte-exact; only the default raw allowance origin changes.', 'Root selection qualification is retained: uninitialized performs the existing Instant::now monotonic read; no new author callback or supplied DateHost read is introduced.'],findings=[],limits='Static source composition review only. No project execution, live edits or runtime-result inference. Review is bound to source-candidate-1, not a later source snapshot.')
report['audit_source']=bind(R/'audit.py')
q=R/'source-review.json';q.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(bind(q)))
