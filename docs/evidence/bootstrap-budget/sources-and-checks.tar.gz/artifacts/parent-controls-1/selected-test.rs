#[test]
fn bootstrap_raw_allowance_is_separate_and_still_finite() {
    assert_eq!(MAX_STEPS, 100_000);
    assert_eq!(MAX_HEAP, 8 * 1024 * 1024);
    for amount in [1_000_000usize, 1_000_001] {
        let mut raw = Runtime::uninitialized();
        assert_eq!(raw.steps, 1_000_000);
        let allocated = raw.allocated;
        let result = raw.work(amount);
        assert_eq!(raw.steps, 0);
        assert_eq!(raw.allocated, allocated);
        assert!(raw.objects.is_empty());
        assert!(raw.native_properties.is_empty());
        assert!(raw.frames.is_empty());
        if amount == 1_000_000 {
            result.unwrap();
            assert!(raw.work(1).unwrap_err().is_resource_limit());
            assert_eq!(raw.steps, 0);
        } else {
            assert!(result.unwrap_err().is_resource_limit());
        }
    }
}
