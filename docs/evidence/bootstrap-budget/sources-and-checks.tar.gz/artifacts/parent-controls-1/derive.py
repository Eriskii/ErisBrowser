"""Author an external, append-only test hold using inert source processing."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

P = Path('/tmp/eris-bootstrap-budget-plan-1')
W = P / 'worktree'
H = P / 'parent-controls-1'
BASE = '15226307b153da0857f80486d5f23c375b6b2add'
REL = 'src/script/bootstrap_tests.rs'
CONTROL_SHA = '72221c8258c58d3d1a5832e5691dd0e22c747dfcbaace443c472ac81331dddcc'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def binding(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

assert not (H / 'source-ready.json').exists(), 'Do not overwrite a sealed hold'
parent = json.loads((P / 'source-parent.json').read_text())
assert parent['base'] == BASE
selected = json.loads((P / 'root/selection-1.json').read_text())
assert selected['published_base'] == BASE
control = json.loads((P / 'controls-proposed.json').read_text())['new_groups'][0]
source = control['source'].encode()
assert sha(source) == CONTROL_SHA == control['sha256']
name = control['name']
assert re.search(rb'fn ' + name.encode() + rb'\(\)', source)

before = (W / REL).read_bytes()
published = subprocess.check_output(['git', '-C', str(W), 'show', BASE + ':' + REL])
assert published == before == (P / 'source-snapshots' / REL).read_bytes()
assert sha(before) == parent['source_sha256'][REL]
assert name.encode() not in before
assert before.endswith(b'\n') and source.startswith(b'#[test]\n') and source.endswith(b'\n')
raw = before + b'\n' + source
assert raw[:len(before)] == before and raw[len(before) + 1:] == source

script = (W / 'src/script.rs').read_bytes()
assert script == subprocess.check_output(['git', '-C', str(W), 'show', BASE + ':src/script.rs'])
assert script == (P / 'source-snapshots/src/script.rs').read_bytes()
assert sha(script) == parent['source_sha256']['src/script.rs']
assert b'#[cfg(test)]\nmod bootstrap_tests;' in script
assert b'    fn work(&mut self, units: usize) -> Result<()> {' in script
assert b'const MAX_STEPS: usize = 100_000;' in script
assert b'            steps: MAX_STEPS,' in script
assert b'BOOTSTRAP_STEPS' not in source

before_path = H / 'before' / REL
raw_path = H / 'raw' / REL
diff_path = H / 'diffs/src__script__bootstrap_tests.rs.patch'
for path in [before_path, raw_path, diff_path]:
    path.parent.mkdir(parents=True, exist_ok=True)
before_path.write_bytes(before)
raw_path.write_bytes(raw)
(H / 'selected-test.rs').write_bytes(source)
diff = ''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), raw.decode().splitlines(keepends=True), fromfile='a/' + REL, tofile='b/' + REL))
diff_path.write_text(diff)
assert not any(line.startswith('-') and not line.startswith('---') for line in diff.splitlines())
assert len(re.findall(rb'(?m)^#\[test\]$', raw)) == len(re.findall(rb'(?m)^#\[test\]$', before)) + 1

oracle = {
    'status': 'frozen source-derived expectations; unexecuted',
    'name': name,
    'full_name': 'script::bootstrap_tests::' + name,
    'groups': 1,
    'planned_budget_rows': 2,
    'planned_work_calls': 3,
    'selected_source': binding(H / 'selected-test.rs'),
    'parent_api_eligible': True,
    'parent_predicted': {'passed': 0, 'failed': 1, 'first_failure': 'assert_eq!(raw.steps, 1_000_000)', 'actual_from_parent_source': 100000, 'expected_frozen_literal': 1000000},
    'parent_reached_prefix': [
        'MAX_STEPS equals100000 and MAX_HEAP equals8MiB.',
        'First loop row chooses amount1000000.',
        'Runtime::uninitialized constructs its current raw state with steps100000; the first raw allowance equality then fails.'
    ],
    'parent_unreached': [
        'The allocated snapshot and first work(amount) invocation.',
        'Zero-remaining, unchanged allocation and empty object/native/frame assertions.',
        'Exact admission result and subsequent one-unit refusal.',
        'The second loop row with amount1000001 and its resource refusal.'
    ],
    'selected_candidate_expectations': [
        'Raw uninitialized starts with1000000 while author MAX_STEPS remains100000 and heap remains8MiB.',
        'First row admits work1000000 to zero, then refuses work1 with ResourceLimit and remaining zero.',
        'Second fresh row refuses work1000001 with ResourceLimit and remaining zero.',
        'Work admission/refusal preserves allocated and creates no objects, native metadata entries or evaluation frames.'
    ],
    'no_reset': 'The exact selected test contains no steps assignment, constructor substitution, alternate initializer or reset between work calls.',
    'limits': 'The new group tests the finite raw counter only. Existing bootstrap/public/date-host/author/host controls remain responsible for initialization, public reset and error propagation. No candidate outcome is asserted here.'
}
write_json(H / 'oracle.json', oracle)
registration = {
    'status': 'existing registration retained; no registration edit',
    'module': REL,
    'declaration': '#[cfg(test)]\nmod bootstrap_tests;',
    'declaration_owner': 'src/script.rs',
    'published_owner_sha256': sha(script),
    'new_production_symbols_required': [],
    'visibility': 'Existing bootstrap_tests is a child of script, imports super::*, and can access Runtime::uninitialized, work, counters and private fields. No API or visibility change.',
    'scope': 'Only the complete existing test module gains the selected exact source as a byte append.'
}
write_json(H / 'registration.json', registration)

manifest = {
    'status': 'source_ready_unexecuted',
    'published_base': BASE,
    'scope': 'One selected parent-compatible finite-bootstrap-budget test group, appended to the existing registered bootstrap_tests module. No live edits or project execution.',
    'groups': 1,
    'source_paths': 1,
    'files': [{
        'relative_path': REL,
        'new_file': False,
        'before': binding(before_path),
        'raw': binding(raw_path),
        'diff': binding(diff_path),
        'transformation': 'raw = before + one LF separator + selected-test.rs, byte exact',
        'published_before_git_blob': hashlib.sha1(b'blob ' + str(len(before)).encode() + b'\0' + before).hexdigest()
    }],
    'selected_source_sha256': CONTROL_SHA,
    'source_bindings': [binding(P / 'source-ready.json'), binding(P / 'controls-proposed.json'), binding(P / 'root/selection-1.json'), binding(P / 'source-parent.json'), binding(P / 'source-snapshots/src/script.rs')],
    'artifacts': [binding(H / item) for item in ['selected-test.rs', 'oracle.json', 'registration.json', 'derive.py']],
    'checks': [
        'Exact selected source hash matches controls-proposed.json; no expectation or literal changes.',
        'Before bytes independently join published Git blob, live clean parent, proposal snapshot and1675-entry parent inventory.',
        'All original module bytes remain as an exact prefix; unified diff has only additions; exactly one test declaration is added.',
        'Existing parent module registration and private APIs suffice; no BOOTSTRAP_STEPS reference or production edit is needed to compile the parent control.',
        'Expected first parent failure and later unreachable statements are recorded before any execution.',
        'Only inert standard-library source/hash/diff processing and read-only Git blob access occurred.'
    ],
    'ownership': 'Script separately owns production and existing-test migrations. This full-file parent append must be composed with those migrations using their published-before lineage, not replace their later changes.'
}
write_json(H / 'source-ready.json', manifest)
print(json.dumps(binding(H / 'source-ready.json')))
