from pathlib import Path
import re,json,hashlib,subprocess
P=Path('/tmp/eris-bootstrap-budget-plan-1');B=Path('/tmp/eris-startup-headroom-plan-1');W=B/'worktree'
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def dump(n,x):
 p=P/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def sha(s):return hashlib.sha256(s.encode()).hexdigest()
base=json.loads((B/'source-candidate-3.json').read_text());inventory=base['source_sha256']
# Whole checked-in Rust source roster, including the three selected untracked tests.
rust=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','--','*.rs'],cwd=W,text=True).splitlines();assert len(rust)==len(set(rust))
outside=[rel for rel in rust if rel not in inventory]
for rel in rust:
 if rel in inventory:assert bind(W/rel)['sha256']==inventory[rel],rel
 else:
  assert '::uninitialized(' not in (W/rel).read_text() and '.finish_bootstrap(' not in (W/rel).read_text(),rel
  assert subprocess.check_output(['git','show','HEAD:'+rel],cwd=W)==(W/rel).read_bytes(),rel
scan=[];raw_groups=[];snapshot_paths={'src/script.rs'}
for rel in rust:
 s=(W/rel).read_text();lines=s.splitlines();starts=[(i,re.search(r'\bfn\s+(\w+)',x).group(1)) for i,x in enumerate(lines) if re.match(r'\s*(?:pub(?:\([^)]*\))?\s+)?(?:async\s+)?fn\s+\w+',x)]
 for i,line in enumerate(lines):
  if re.search(r'uninitialized|finish_bootstrap|initialize_bootstrap|\b306\b|99_694|99_693|99694|99693',line):
   owner=next(((at,name) for at,name in reversed(starts) if at<=i),None)
   scan.append(dict(path=rel,line=i+1,function=owner[1] if owner else None,text=line))
 if '::uninitialized(' not in s:continue
 snapshot_paths.add(rel)
 for idx,(start,name) in enumerate(starts):
  end=starts[idx+1][0] if idx+1<len(starts) else len(lines);part='\n'.join(lines[start:end])+'\n'
  if not re.search(r'(?:Runtime|Self)::uninitialized\(',part):continue
  raw_groups.append(dict(path=rel,function=name,line=start+1,test=bool(start and '#[test]' in '\n'.join(lines[max(0,start-3):start])),source=part,source_sha256=sha(part),raw_calls=len(re.findall(r'(?:Runtime|Self)::uninitialized\(',part)),finish_calls=len(re.findall(r'\.finish_bootstrap\(',part))))
# Exact mandatory migrations; literals below are proposals, not applied source.
rows=[]
def row(path,group,changes,why):rows.append(dict(path='src/script/'+path,group=group,changes=[dict(before=a,after=b) for a,b in changes],reason=why))
row('bootstrap_tests.rs','bootstrap_initial_reserve_heap_failure_is_returned_unchanged',[('assert_eq!(witness.steps, MAX_STEPS - 1);','assert_eq!(witness.steps, BOOTSTRAP_STEPS - 1);')],'Fresh raw state pays the unchanged single reserve-work unit before heap refusal.')
row('bootstrap_tests.rs','bootstrap_late_work_boundary_returns_error_or_the_complete_realm',[('let consumed = MAX_STEPS - complete.steps;','let consumed = BOOTSTRAP_STEPS - complete.steps;')],'Consumed startup work remains99694. Keep exact/one-short injected consumed budgets and same resource errors.')
row('bootstrap_tests.rs','bootstrap_convenience_and_try_paths_separate_work_and_retain_heap',[('assert_eq!(reference.steps, 306);','assert_eq!(reference.steps, 900_306);')],'Only raw default remainder changes. All five public constructor MAX_STEPS and heap/metadata equality checks remain exact.')
for path,group,old,new in [
 ('array_buffer/bootstrap/tests.rs','array_buffer_bootstrap_reports_raw_combined_initialization','assert!(runtime.steps < MAX_STEPS);','assert!(runtime.steps < BOOTSTRAP_STEPS);'),
 ('data_view/tests.rs','data_view_bootstrap_reports_actual_remaining_budget','assert!(runtime.steps < MAX_STEPS);','assert!(runtime.steps < BOOTSTRAP_STEPS);'),
 ('dom_bindings/identity_tests.rs','dom_parent_bootstrap_reports_actual_remaining_budget_and_capacities','assert!(runtime.steps < MAX_STEPS);','assert!(runtime.steps < BOOTSTRAP_STEPS);'),
 ('object_is/tests.rs','object_is_bootstrap_reports_actual_charged_budget','assert!(runtime.steps < MAX_STEPS);','assert!(runtime.steps < BOOTSTRAP_STEPS);'),
 ('typed_array/intrinsics/views_tests.rs','typed_array_views_metadata_raw_bootstrap_diagnostic_and_public_reset','assert!(raw.steps < MAX_STEPS);','assert!(raw.steps < BOOTSTRAP_STEPS);'),
 ('dom_prototypes/tests.rs','dom_native_metadata_slot_allocation_is_admitted_before_factory_return','assert_eq!(runtime.steps, MAX_STEPS);','assert_eq!(runtime.steps, BOOTSTRAP_STEPS);')]:
 row(path,group,[(old,new)],'The object is private raw state; public and fixture-reset MAX_STEPS assertions elsewhere in the file remain unchanged.')
row('processing_instruction/display_key_tests.rs','startup_headroom_raw_observation_precedes_the_frozen_99694_work_witness',[
 ('100_000 - runtime.steps,','BOOTSTRAP_STEPS - runtime.steps,'),('assert_eq!(100_000 - runtime.steps, 99_694);','assert_eq!(BOOTSTRAP_STEPS - runtime.steps, 99_694);'),('assert_eq!(runtime.steps, 306);','assert_eq!(runtime.steps, 900_306);')],'Change both diagnostic and assertion origin; retain literal99694 consumed work, object/global/native/prototype/idle expectations.')
row('typed_array/tests.rs','typed_array_bootstrap_reports_types_and_reconciles_installation_ledger',[
 ('            + 279\n    );','            + 279\n            + (BOOTSTRAP_STEPS - MAX_STEPS)\n    );')],'Append an explicitly documented allowance-origin delta900000 to the existing100000-based cumulative remainder expression. Preserve every installation term and the entire heap expression, including the newly corrected-1132.')
row('test262_host/quota_tests.rs','host_actual_inline_layout_and_inactive_bootstrap_are_observed_without_new_allowance',[('assert_eq!(runtime.steps, 306);','assert_eq!(runtime.steps, 900_306);')],'Only raw inactive startup remainder changes. Preserve host-none/print/DONE absence, all layouts and public100000/8MiB assertion. Name remains retained; document that no new host/author allowance is introduced.')
assert len(rows)==12 and len({r['path'] for r in rows})==10
bygroup={(r['path'],r['group']):r for r in rows}
for r in rows:
 g=next(g for g in raw_groups if g['path']==r['path'] and g['function']==r['group'])
 for delta in r['changes']:assert delta['before'] in g['source'],(r['path'],r['group'],delta['before'])
 r['current_group_source_sha256']=g['source_sha256'];snapshot_paths.add(r['path'])
for g in raw_groups:
 k=(g['path'],g['function'])
 if k in bygroup:g['classification']='mandatory_migration'
 elif g['path']=='src/script.rs':g['classification']='production_entry_only'
 elif g['function'] in ['cached_pi_keys_raw_bootstrap_with_promise_uses_the_frozen_99694_work_boundary','text_metadata_keys_raw_bootstrap_uses_99694_work_and_preserves_public_reset','promise_full_raw99694_and_public_reset_preserve_empty_paid_arenas']:
  g['classification']='retain_explicit_injected_99693_99694_100000_rows'
 elif g['function']=='before_installation':g['classification']='retain_real_preparation_then_explicit_MAX_STEPS_fixture_reset'
 elif g['function']=='object_has_own_final_initializer_exact_and_one_short_admission':g['classification']='retain_dynamic_initial_steps_difference_and_exact_heap_cuts'
 elif g['path']=='src/script/bootstrap_tests.rs':g['classification']='retain_existing_failure_public_or_nested_author_control'
 else:g['classification']='retain_positive_or_heap_identity_diagnostic_no_old_budget_origin'
assert sum(g['classification']=='mandatory_migration' for g in raw_groups)==12
# All applicable publication/control sources to anchor the proposal, not a complete build-dependency claim.
extra=['src/date_host.rs','src/script/microtasks.rs','src/script/microtask_tests.rs','src/script/microtask_budget_tests.rs','src/script/test262_host.rs','src/script/test262_host/tests.rs','src/script/machine.rs','src/script/parser.rs','src/script/code.rs','src/script/date_builtins.rs','src/page.rs','src/worker.rs','src/bin/eris-js.rs','src/bin/eris-js/test262_host.rs','src/bin/eris-js/test262_host_tests.rs']
for rel in extra:
 if (W/rel).is_file():snapshot_paths.add(rel)
bindings=[]
for rel in sorted(snapshot_paths):
 p=W/rel;assert bind(p)['sha256']==inventory[rel];copy=P/'source-snapshots'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(p.read_bytes());bindings.append(dict(relative=rel,source=bind(p),snapshot=bind(copy)))
dump('source-bindings.json',dict(status='prospective_unpublished_base',base_commit=base['base'],selected_base=bind(B/'source-candidate-3.json'),prior_review=bind(B/'current-source-review-1/source-review-2.json'),files=bindings,qualification='Candidate3 is not yet the selected published base for this next checkpoint; later refresh must prove exact joins. Snapshots are bounded sources, while census scans the complete read-only Git Rust roster.'))
dump('census-scan.json',dict(rust_files=[dict(path=rel,sha256=bind(W/rel)['sha256']) for rel in rust],matches=scan,outside_selected_inventory=outside,outside_qualification='34 historical evidence Rust files and one separate tools/vulkan-probe main are Git-parent-exact and contain no raw Runtime construction; they are included in the scan but not claimed as selected build inputs.',query='All uninitialized/finish_bootstrap/initialize_bootstrap and306/99694/99693 hits in every tracked plus selected untracked Rust source; manually distinguish author fixtures from raw construction.',raw_call_sites=sum(g['raw_calls'] for g in raw_groups),raw_containing_functions=len(raw_groups),raw_function_paths=len({g['path'] for g in raw_groups})))
dump('raw-controls-census.json',dict(groups=raw_groups,qualification='Exact source excerpts start at each owning function and end at the next function declaration; trailing cfg/attributes may be included. No test or project module was imported or run. All raw-call-containing functions are classified.'))
dump('migration-census.json',dict(status='proposed mandatory existing-test changes before implementation',files=10,groups=12,rows=rows,unchanged_explicit_allowances=[dict(path=g['path'],group=g['function'],source_sha256=g['source_sha256']) for g in raw_groups if g['classification']=='retain_explicit_injected_99693_99694_100000_rows'],rules=['No heap formula or limit changes.','Do not replace every MAX_STEPS in a file: preserve author/public/explicit fixture resets.','Keep all literal JS, descriptor/identity/count checks, exact resource errors and preceding formula terms.','No test rename is required; add narrow clarification to host inactive-budget wording if necessary without rewriting historical evidence.','Any later additional migration needs its own disclosed source-derived additive hold, not a broad search-and-replace.']))
print(json.dumps(dict(rust_files=len(rust),raw_calls=sum(g['raw_calls'] for g in raw_groups),functions=len(raw_groups),mandatory_files=10,mandatory_groups=12,snapshots=len(bindings))))
