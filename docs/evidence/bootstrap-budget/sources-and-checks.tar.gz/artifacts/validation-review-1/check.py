"""Read-only validation audit; reads logs/artifacts, never runs project code."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import re

P = Path('/tmp/eris-bootstrap-budget-plan-1')
W = P / 'worktree'
OUT = P / 'validation-review-1'
OLD = Path('/tmp/eris-startup-headroom-plan-1')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}

def read(name):
    return json.loads((P / name).read_text())

def verify_binding(row):
    actual = bind(Path(row['path']))
    for key in ('bytes', 'sha256'):
        if key in row:
            assert actual[key] == row[key], (row['path'], key)

def walk_bindings(value):
    if isinstance(value, dict):
        if 'path' in value and 'sha256' in value:
            verify_binding(value)
        for nested in value.values():
            walk_bindings(nested)
    elif isinstance(value, list):
        for nested in value:
            walk_bindings(nested)

def receipt(directory, label, expected_exit=0):
    path = directory / (label + '.json')
    row = json.loads(path.read_text())
    log = directory / (label + '.log')
    assert row['exit'] == expected_exit and sha(log.read_bytes()) == row['sha256']
    return {'receipt': bind(path), 'log': bind(log), 'command': row['command'], 'exit': row['exit']}, log.read_text()

def parse_test_log(text):
    target = None
    names = []
    rows = []
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith('Running '):
            target = stripped.removeprefix('Running ').removeprefix('unittests ').split(' (', 1)[0]
        elif stripped.startswith('Doc-tests '):
            target = stripped
        elif line.startswith('test ') and line.endswith(' ... ok'):
            assert target is not None
            names.append(target + '::' + line[5:-7])
        elif line.startswith('test result: '):
            counts = re.findall(r'(\d+) (?:passed|failed|ignored|measured|filtered out)', line)
            assert len(counts) == 5
            rows.append(list(map(int, counts)))
    totals = [sum(row[i] for row in rows) for i in range(5)]
    assert len(names) == len(set(names)) == totals[0]
    return {'result_rows': len(rows), 'totals': totals, 'passed_names': sorted(names)}

if not (P / 'root/final-validation.json').exists():
    raise SystemExit('Awaiting final-validation.json; no final review written.')
assert not (OUT / 'final-review.json').exists(), 'Do not overwrite a sealed review'
ledger = read('root/final-validation.json')
assert ledger['status'] == 'pass'
walk_bindings(ledger)
parent = read('source-parent.json')['source_sha256']
current = read('source-final.json')['source_sha256']
assert (P / 'source-final.json').read_bytes() == (P / 'source-candidate-1.json').read_bytes()
assert set(current) == set(parent) and len(current) == 1675
for name, digest in current.items():
    assert sha((W / name).read_bytes()) == digest, name
changed = sorted(name for name in current if parent[name] != current[name])
production = read('production-1/source-ready.json')
walk_bindings(production)
assert changed == sorted(row['relative'] for row in production['files']) == ledger['changed_source_paths']
assert len(changed) == 11
control = (P / 'parent-controls-1/selected-test.rs').read_bytes()
assert sha(control) == '72221c8258c58d3d1a5832e5691dd0e22c747dfcbaace443c472ac81331dddcc'
for row in production['files']:
    before = Path(row['before']['path']).read_bytes()
    raw = Path(row['raw']['path']).read_bytes()
    assert sha(before) == parent[row['relative']]
    expected = raw + b'\n' + control if row['relative'] == 'src/script/bootstrap_tests.rs' else raw
    assert (W / row['relative']).read_bytes() == expected

before_script = (P / 'production-1/before/src/script.rs').read_text()
actual_script = (W / 'src/script.rs').read_text()
addition = '// Fixed intrinsic initialization has a separate finite work allowance.\n// Successful public construction resets author work to MAX_STEPS.\nconst BOOTSTRAP_STEPS: usize = 1_000_000;\n'
assert actual_script.count(addition) == 1
assert actual_script.count('            steps: BOOTSTRAP_STEPS,') == 1
inverse = actual_script.replace(addition, '', 1).replace('            steps: BOOTSTRAP_STEPS,', '            steps: MAX_STEPS,', 1)
assert inverse == before_script
assert 'runtime.initialize_bootstrap()?;\n        runtime.steps = MAX_STEPS;' in actual_script
for relative in ['src/script/processing_instruction/key_cache_tests.rs', 'src/script/promises/install_tests.rs', 'src/script/text_operations/key_cache_tests.rs']:
    assert current[relative] == parent[relative]

source_peer = read('current-source-review-1/source-review.json')
walk_bindings(source_peer)
assert source_peer['status'] == 'clear_current_source_only' and not source_peer['findings']

parent_receipt, parent_log = receipt(P / 'validation', 'parent-control-1', 101)
assert 'left: 100000\n right: 1000000' in parent_log
assert 'bootstrap_tests.rs:418:9' in parent_log
assert '0 passed; 1 failed; 0 ignored; 0 measured; 2791 filtered out' in parent_log
parent_raw = (P / 'parent-controls-1/raw/src/script/bootstrap_tests.rs').read_text().splitlines()
assert parent_raw[417].strip() == 'assert_eq!(raw.steps, 1_000_000);'
assert parent_raw[418].strip() == 'let allocated = raw.allocated;'

focused_receipt, focused_log = receipt(P / 'validation', 'bootstrap-focused-1')
focused = parse_test_log(focused_log)
assert focused['totals'] == [53, 0, 0, 0, 2739]
observation_line = 'TYPED_ARRAY_BOOTSTRAP remaining=900306 allocated=1744317 objects=752 capacity=752 native=299 prototypes=25 globals=212'
assert observation_line in focused_log
prior_observation_receipt, prior_observation_log = receipt(OLD / 'validation', 'candidate-controls-1')
assert 'STARTUP_HEADROOM raw_work=99694 remaining=306 allocated=1744317 objects=752 capacity=752 globals=212 natives=299 prototypes=25' in prior_observation_log

new_name = 'src/lib.rs::script::bootstrap_tests::bootstrap_raw_allowance_is_separate_and_still_finite'
comparisons = []
authority = read('root/rust-validation.json')
walk_bindings(authority)
for label, old_label, total in [('default-full-1', 'default-full-2', 3132), ('host-vulkan-full-1', 'host-vulkan-full-1', 3486)]:
    now_bind, now_text = receipt(P / 'validation', label)
    old_bind, old_text = receipt(P / 'rust-parent', old_label)
    now, old = parse_test_log(now_text), parse_test_log(old_text)
    assert now['totals'] == [total, 0, 0, 0, 0]
    assert old['totals'] == [total - 1, 0, 0, 0, 0]
    assert now['result_rows'] == old['result_rows'] == 52
    assert set(now['passed_names']) - set(old['passed_names']) == {new_name}
    assert not set(old['passed_names']) - set(now['passed_names'])
    assert '--include-ignored' in now_bind['command']
    root_row = next(row for row in authority['comparisons'] if Path(row['current']['log']['path']).name == label + '.log')
    for key in ('totals', 'result_rows', 'passed_names'):
        assert root_row['current'][key] == now[key]
        assert root_row['previous'][key] == old[key]
    comparisons.append({'current': now_bind, 'previous': old_bind, 'passed': total, 'previous_passed': total - 1, 'result_rows': 52, 'failed_ignored_measured_filtered': [0, 0, 0, 0], 'added': [new_name], 'removed': [], 'renamed': [], 'passed_roster_sha256': sha(('\n'.join(now['passed_names']) + '\n').encode())})

strict = []
for label in ['format-check-1', 'default-clippy-1', 'host-vulkan-clippy-1']:
    entry, log = receipt(P / 'validation', label)
    strict.append(entry)
    if 'clippy' in label:
        assert '--all-targets' in entry['command'] and entry['command'][-2:] == ['-D', 'warnings']
    else:
        assert entry['command'][-1] == '--check'

release, release_log = receipt(P / 'validation', 'host-release-1')
assert '+1.88.0' in release['command'] and '--release' in release['command'] and 'test262-host' in release['command']
assert 'Finished `release` profile' in release_log
identity = read('eris-js-host-final-1.json')
walk_bindings(identity)
assert identity['source_inventory'] == bind(P / 'source-final.json')
assert identity['build_receipt'] == release['receipt']
replay = read('root/replay-validation.json')
walk_bindings(replay)
assert replay['status'] == 'pass' and replay['binary'] == identity
replays = []
for row in replay['comparisons']:
    old = json.loads(Path(row['parent']['path']).read_text())
    new = json.loads(Path(row['report']['path']).read_text())
    for key in ('cases', 'harness_preflight', 'runner_policy', 'runner_policy_sha256', 'corpus_manifest_sha256', 'counts'):
        assert new[key] == old[key], (row['profile'], key)
    assert len(new['cases']) == row['cases'] and len(new['harness_preflight']) == row['controls']
    assert new['harness_preflight_passed'] and all(item['verified'] for item in new['harness_preflight'])
    assert new['regressions'] == new['improvements'] == []
    assert new['binary_sha256'] == identity['sha256']
    run, log = receipt(P / 'validation', Path(row['receipt']['path']).stem)
    assert '--baseline' in run['command'] and str(P / 'eris-js-host-final-1') in run['command']
    baseline_relative = run['command'][run['command'].index('--baseline') + 1]
    assert current[baseline_relative] == parent[baseline_relative]
    replays.append({'profile': row['profile'], 'parent': row['parent'], 'report': row['report'], 'run': run, 'cases': row['cases'], 'controls': row['controls'], 'counts': new['counts'], 'full_case_array_exact': True, 'full_control_array_exact': True, 'baseline_sha256_unchanged': current[baseline_relative]})
assert len(replays) == 4 and sum(row['cases'] for row in replays) == 1050 and sum(row['controls'] for row in replays) == 348
assert ledger['budgets'] == {'bootstrap': 1000000, 'author': 100000, 'cumulative_heap': 8388608}
assert ledger['default_passed'] == 3132 and ledger['host_vulkan_passed'] == 3486
assert ledger['exact_case_records'] == 1050 and ledger['exact_harness_records'] == 348

review = {
    'status': 'clear',
    'scope': 'Independent completed source/log/receipt/replay review; no project execution or live edits. Documentation and publication archive are outside this receipt.',
    'final_ledger': bind(P / 'root/final-validation.json'),
    'source': bind(P / 'source-final.json'),
    'candidate_source': bind(P / 'source-candidate-1.json'),
    'parent_source': bind(P / 'source-parent.json'),
    'source_peer': bind(P / 'current-source-review-1/source-review.json'),
    'source_checks': {'selected_inputs': 1675, 'changed_paths': changed, 'production_paths': 1, 'migration_paths': 10, 'migration_groups': 12, 'new_groups': 1, 'candidate_final_byte_exact': True, 'all_live_hashes_match': True, 'production_two_site_inverse_exact': True, 'three_explicit_allowance_matrices_unchanged': True},
    'parent_control': {'run': parent_receipt, 'passed': 0, 'failed': 1, 'first_failure': 'raw.steps100000 versus frozen1000000 at exact appended line418', 'reached': 'Author/heap constant checks and first raw construction.', 'unreached': 'Allocated capture, every work call/state assertion, second row. No later parent success is inferred.'},
    'focused': {'run': focused_receipt, 'passed': 53, 'failed': 0, 'filtered': 2739},
    'observed_startup': {'default_rust': '1.88.0', 'raw_remaining': 900306, 'consumed_from_selected_origin': 99694, 'accounted_allocation': 1744317, 'prior_accounted_allocation': 1744317, 'objects': 752, 'object_capacity': 752, 'native_registry_entries': 299, 'prototypes': 25, 'globals': 212, 'prior_observation': prior_observation_receipt},
    'full_suites': comparisons,
    'strict_checks': strict,
    'release': {'run': release, 'identity': bind(P / 'eris-js-host-final-1.json'), 'binary': {key: identity[key] for key in ['path', 'bytes', 'sha256']}},
    'replay_receipt': bind(P / 'root/replay-validation.json'),
    'replays': replays,
    'exact_cases': 1050,
    'exact_controls': 348,
    'baseline_changes': 0,
    'qualifications': [
        'The selected cap increases raw trusted startup allowance, not startup work consumption or successful public author work. Existing per-operation, heap, callback, parser and host-audit limits remain byte-exact outside selected migrations.',
        'The earlier no-host-reads rationale is corrected by the retained Instant::now qualification; no supplied DateHost clock/timezone discovery or author callback occurs during initialization.',
        'Complete Promise arrays preserve existing failed and unsupported cases as well as passed cases. Verified harnesses and successful baseline comparison are not an all-cases-pass claim.',
        'No Python full suite rerun, new API, host policy, GPU implementation, acquired-window, security or CPU/RSS performance claim is made.',
        'The1675 selected source inventory is not claimed to be the complete build graph. Logical allocated bytes remain accounting observations on the recorded configuration.'
    ],
    'finalizer_source_review': 'Root finalizer references completed strict/source/roster/replay receipts. Its hard-coded totals have been independently reconciled to raw logs and full arrays here; parent reachability and no-new-API qualifications match evidence.',
    'review_inputs': [bind(P / name) for name in ['root/finalize-validation.py', 'root/freeze-release-and-replay.py', 'root/rust-validation.json', 'root/parent-validation.json', 'root/candidate-observation-1.json', 'root/selection-qualification-1.json', 'production-1/source-ready.json', 'parent-controls-1/source-ready.json']],
    'findings': [],
    'reviewer_script': bind(Path(__file__))
}
(OUT / 'final-review.json').write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps(bind(OUT / 'final-review.json')))
