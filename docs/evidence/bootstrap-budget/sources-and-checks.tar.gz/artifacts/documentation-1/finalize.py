from pathlib import Path
import json,hashlib,re,difflib
P=Path('/tmp/eris-bootstrap-budget-plan-1');D=P/'documentation-1';W=P/'worktree'
def ref(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(p):return json.loads(p.read_text())
def verify(r):
 p=Path(r['path']);assert ref(p)=={k:r[k] for k in ['path','bytes','sha256']};return p
f=read(P/'root/final-validation.json');rv=read(P/'root/rust-validation.json');rep=read(P/'root/replay-validation.json')
assert f['status']=='pass' and f['default_passed']==3132 and f['host_vulkan_passed']==3486
assert (P/'source-final.json').read_bytes()==(P/'source-candidate-1.json').read_bytes()
assert f['startup']['consumed_work']==99694 and f['startup']['raw_remaining']==900306
raw_counts=[]
for c,total in zip(rv['comparisons'],[3132,3486]):
 cur=c['current'];prev=c['previous'];verify(cur['receipt']);log=verify(cur['log']).read_text();verify(prev['receipt']);verify(prev['log'])
 rows=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',log)
 sums=[sum(int(row[i]) for row in rows) for i in range(5)]
 assert sums==[total,0,0,0,0] and len(rows)==52
 assert set(cur['passed_names'])-set(prev['passed_names'])==set(rv['new_names']) and set(prev['passed_names'])<=set(cur['passed_names'])
 receipt=read(Path(cur['receipt']['path']));assert receipt['exit']==0 and '--include-ignored' in receipt['command']
 raw_counts.append({'total':total,'result_rows':len(rows),'receipt':cur['receipt'],'log':cur['log']})
for r in f['strict_checks']:
 receipt=read(verify(r['receipt']));verify(r['log']);assert receipt['exit']==0
verify(f['release_binary']);assert read(verify(f['release_binary']['build_receipt']))['exit']==0
case_total=control_total=0
for c in rep['comparisons']:
 old=read(verify(c['parent']));new=read(verify(c['report']));assert new['cases']==old['cases'] and new['harness_preflight']==old['harness_preflight']
 assert all(v['verified'] for v in new['harness_preflight'])
 assert new['regressions']==[] and new['improvements']==[] and new['counts']==old['counts']
 for k in ['corpus_manifest_sha256','runner_policy','runner_policy_sha256','revision','source_files','mode_cases']:assert new[k]==old[k]
 verify(c['receipt']);verify(c['log']);assert read(Path(c['receipt']['path']))['exit']==0
 case_total+=len(new['cases']);control_total+=len(new['harness_preflight'])
assert (case_total,control_total)==(1050,348)
chapter=D/'raw/docs/bootstrap-budget.md';s=chapter.read_text();assert s.count('PENDING_FINAL_VALIDATION_DETAILS')==1
s=s.replace('PENDING_FINAL_VALIDATION_DETAILS','''Complete `--include-ignored` runs pass **3,132 Rust 1.88 default tests** and
**3,486 Rust 1.99 tests with `test262-host,vulkan-raster`**. Both report 52 result
rows with no failed, ignored or filtered tests. Each retains the complete prior
roster and adds exactly the one new control, with no test-name changes. Strict
all-target Clippy passes in both configurations; the formatting check passes.

The rebuilt Rust 1.88 release host adapter preserves every **1,050 case-mode
record and 348 harness records** across the four existing Promise profiles.
Complete case and control arrays match the published parent, including failed
and unsupported outcomes. All controls verify, with zero regressions,
improvements or baseline changes. No new standalone Python-suite or upstream
selection result is claimed.''')
chapter.write_text(s)
p=D/'raw/docs/VALIDATION.md';s=p.read_text();assert s.count('PENDING_FINAL_VALIDATION_SUMMARY')==1
s=s.replace('PENDING_FINAL_VALIDATION_SUMMARY','''Complete `--include-ignored` runs pass **3,132 Rust 1.88 default tests** and
**3,486 Rust 1.99 tests with `test262-host,vulkan-raster`**, each across 52 result
rows with no failed, ignored or filtered tests. Both retain every prior test
identity and add exactly one group. Strict all-target Clippy passes in both
configurations, and formatting passes.

The rebuilt Rust 1.88 release host adapter retains all **1,050 case records and
348 harness records** across the four existing Promise profiles. Complete arrays
match the published parent, including failures and unsupported outcomes; all
controls verify. There are no regressions, improvements or baseline changes.''');p.write_text(s)
files=read(D/'draft-manifest.json')['files'];checks=[]
for row in files:
 rel=row['relative'];before=(D/'before'/rel).read_text() if row['before'] else '';after=(D/'raw'/rel).read_text()
 assert 'PENDING_' not in after
 diff=D/'diffs'/(rel+'.patch');diff.write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
 row['raw']=ref(D/'raw'/rel);row['diff']=ref(diff)
 if row['before']:assert ref(D/'before'/rel)==row['before']
 # Only newly introduced local links need a target check here; older content is unchanged.
 old_links=set(re.findall(r'\]\(([^)]+)\)',before))
 for link in set(re.findall(r'\]\(([^)]+)\)',after))-old_links:
  if '://' in link or link.startswith('#'):continue
  target=(Path(rel).parent/link.split('#')[0]).as_posix()
  if target in ['docs/evidence/bootstrap-budget/manifest.json','docs/evidence/bootstrap-budget/sources-and-checks.tar.gz']:
   checks.append({'from':rel,'link':link,'target':target,'status':'planned publication artifact; root packaging owns creation'})
  else:
   assert (D/'raw'/target).is_file() or (W/target).is_file(),(rel,link,target)
   checks.append({'from':rel,'link':link,'target':target,'status':'resolves in held composition or existing repository'})
a=(D/'raw/docs/VALIDATION.md').read_text();b=(D/'before/docs/VALIDATION.md').read_text()
assert a[a.index('## Shared startup metadata payloads'):]==b[b.index('## Shared startup metadata payloads'):]
a=(D/'raw/docs/runtime-budget-boundary.md').read_text();b=(D/'before/docs/runtime-budget-boundary.md').read_text()
assert a[a.index('This makes the boundary explicit'):]==b[b.index('This makes the boundary explicit'):]
notes={'status':'checked','raw_counts':raw_counts,'replay_arrays':{'cases':case_total,'controls':control_total,'full_arrays_equal':True},'source_final':f['source'],'strict_checks':f['strict_checks'],'release_binary':f['release_binary'],'historical_suffixes_byte_exact':['docs/VALIDATION.md:Shared startup metadata payloads and all later sections','docs/runtime-budget-boundary.md:This makes the boundary explicit and all later original text'],'links':checks}
(D/'claim-checks.json').write_text(json.dumps(notes,indent=2)+'\n')
manifest={'status':'source_ready_documentation_only','published_base':f['base'],'files':files,'source':f['source'],'validation':ref(P/'root/final-validation.json'),'rust_ledger':ref(P/'root/rust-validation.json'),'replay_ledger':ref(P/'root/replay-validation.json'),'parent_control':ref(P/'root/parent-validation.json'),'policy_review':ref(P/'policy-doc-review-1/source-review.json'),'selection_qualification':ref(P/'policy-doc-review-1/selection-wording-correction.json'),'checks':ref(D/'claim-checks.json'),'qualifications':['Documentation-only external hold; no live edits or project execution.','The trusted initialization cap increases; author100000, cumulative8MiB, operation tariffs, identities and author reset sites stay unchanged.','The retained monotonic Instant read is explicit; no zero-host-read claim.','Parent control later debit rows were unreached; candidate control and focused/full checks are actual.','Historical checkpoint text/evidence stays exact; no prospective API admission, performance, security or remote candidate CI claim.','Two evidence links target the planned root-owned publication artifacts, not files already materialized by this author.']}
(D/'source-ready.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(ref(D/'source-ready.json'));print('chapter_words',len(chapter.read_text().split()))
