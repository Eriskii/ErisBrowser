from pathlib import Path
import hashlib,json,difflib
P=Path('/tmp/eris-bootstrap-budget-plan-1');W=P/'worktree';D=P/'documentation-1'
review=json.loads((P/'policy-doc-review-1/source-review.json').read_text())
bindings={r['relative']:r for r in review['inputs']}
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
files=['README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','docs/SECURITY.md','docs/runtime-budget-boundary.md','docs/VALIDATION.md']
before={}
for rel in files:
 p=W/rel;b=p.read_bytes();assert sha(b)==bindings[rel]['sha256'];before[rel]=b.decode();q=D/'before'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
raw=dict(before)
def replace(rel,old,new):
 assert raw[rel].count(old)==1,(rel,old);raw[rel]=raw[rel].replace(old,new)
replace('README.md','and 1,132 accounted heap bytes. Raw startup leaves 306 units under the same limit.','and 1,132 accounted heap bytes. That checkpoint left 306 raw work units.\n[Trusted initialization](docs/bootstrap-budget.md) now has a separate finite\n1,000,000-unit allowance. Author entries retain 100,000 work units, and both\nphases share the unchanged cumulative 8 MiB allocation budget.')
replace('docs/COMPATIBILITY.md','identities and behavior. It changes accounting without adding API coverage.','identities and behavior. It changes accounting without adding API coverage.\nThe separate [trusted bootstrap budget](bootstrap-budget.md) grants fixed\nintrinsic initialization 1,000,000 work units. Author entries retain 100,000\nand cumulative allocation accounting remains 8 MiB. This policy change adds\nno language or API support.')
replace('docs/ROADMAP.md','work units and 1,132 accounted heap bytes, leaving 306 under the unchanged limit.\nThis headroom does not establish admission for the remaining Promise APIs.','work units and 1,132 accounted heap bytes, leaving 306 at that checkpoint.\n[Trusted initialization](bootstrap-budget.md) now has a separate finite\n1,000,000-unit allowance; author entries retain 100,000 and cumulative heap\naccounting remains 8 MiB. This policy headroom does not establish implementation\nor measured admission for the remaining Promise APIs.')
replace('docs/SECURITY.md','[Runtime construction](runtime-budget-boundary.md) has a separate fixed work\nallowance. A successful bootstrap grants the returned runtime one fresh author\nallowance; failure grants none. Heap accounting remains cumulative. Existing\nscript and host-event entry resets are unchanged, and nested callbacks share\nthe current allowance.','[Trusted runtime initialization](bootstrap-budget.md) has a finite 1,000,000-unit\nwork allowance for fixed intrinsic metadata. Only successful initialization\nreturns a runtime with the separate 100,000-unit author allowance; failure\npublishes no realm. The initialization cap has increased, while author work\nand the shared cumulative 8 MiB allocation budget remain unchanged. Existing\nscript and host-event entry resets are unchanged, and nested callbacks and\nmicrotasks share the current author allowance.')
replace('docs/SECURITY.md','| Runtime bootstrap instructions | 100,000, separately charged before author execution |','| Trusted runtime initialization work | 1,000,000, separately charged before the 100,000-unit author allowance |')
replace('docs/runtime-budget-boundary.md','Runtime construction and author execution each have a fixed 100,000-unit work\nallowance. `try_new` first completes the existing charged bootstrap. Only a\nsuccessful result receives a fresh author allowance; a failure returns unchanged\nwithout publishing a realm. Allocation accounting stays cumulative across both\nphases, under the existing 8 MiB ceiling.','[Trusted intrinsic initialization](bootstrap-budget.md) has a finite 1,000,000-unit\nwork allowance. Author execution retains its separate 100,000-unit allowance.\n`try_new` completes the charged bootstrap before resetting work for the returned\nruntime. A failure returns unchanged without publishing a realm. Allocation\naccounting stays cumulative across both phases, under the existing 8 MiB ceiling.\n\n## Original boundary checkpoint')
validation='''## Separate trusted bootstrap allowance

Fixed intrinsic initialization now has a finite 1,000,000-unit work allowance;
a successfully returned runtime still starts with 100,000 author work units.
The cumulative 8 MiB heap ceiling, charged operation costs, object identities
and author-entry reset sites are unchanged. See the [mechanism and evidence](bootstrap-budget.md).

PENDING_VALIDATION_SUMMARY

'''
assert raw['docs/VALIDATION.md'].startswith('# Validation record\n\n')
raw['docs/VALIDATION.md']=raw['docs/VALIDATION.md'].replace('# Validation record\n\n','# Validation record\n\n'+validation,1)
raw['docs/bootstrap-budget.md']='''# Separate trusted bootstrap allowance

Fixed intrinsic initialization now has a finite **1,000,000-unit work allowance**.
Author entries retain **100,000 work units**, and initialization and execution
share the unchanged **8 MiB cumulative allocation budget**. This increases the
initialization cap; it does not reduce charged work or raise author limits.

The private `Runtime::uninitialized` sets `BOOTSTRAP_STEPS`. The only production
caller, `try_new`, completes object reservation, frame preparation and intrinsic
installation before resetting work to `MAX_STEPS` and returning the realm.
An initialization error propagates before that reset or publication. Convenience
constructors retain their documented panic behavior on the same failure.
Initialization allocations remain charged after the author allowance is granted.

The constructor installs fixed compiled metadata before any author callback or
document-dependent script execution. It retains the existing monotonic start
timestamp. The supplied Date host is assigned after initialization, without
sampling its clock or discovering a timezone during bootstrap. Page, worker,
adapter and stress-tool construction use the same successful-return boundary.

Script and host-event resets still grant only the author allowance. Nested
callbacks, conversions, Promise jobs and microtasks spend its remaining work.
Parser budgets retain their existing limits. Test262 observer setup occurs after
public construction, harnesses use ordinary script entries, and the final audit
spends the body's remaining allowance. No transport, reporting policy or
conformance baseline changes.

PENDING_ACCOUNTING

One new control checks that exactly 1,000,000 raw work units are admitted and
that another unit, or a first request for 1,000,001 units, refuses with zero
remaining work and no allocation or metadata publication. The published parent
is expected to fail its first raw-budget assertion; candidate observations are
recorded separately below. Twelve existing groups in ten files change only
raw-origin accounting assertions or derivations. Their operation costs, heap
assertions and semantic checks remain intact. The three explicit 99,693/99,694/
100,000 initialization matrices retain their exact refusal and success results.
Existing constructor, Date-host, callback and host-audit tests preserve the
success-only author grant and shared-budget boundaries.

PENDING_VALIDATION_DETAILS

This is a resource-policy change, not a CPU-performance or resident-memory
measurement. Initial bindings, B-tree/Rc/string allocation and other existing
paths still contain infallible allocations; the logical ledger does not account
for all process memory or establish production security. Historical checkpoint
measurements and archives retain their original limits and results. Promise.any
and AggregateError remain separate work; additional initialization headroom
alone does not establish their implementation or admission.

The [evidence manifest](evidence/bootstrap-budget/manifest.json) binds the
selected sources, controls, parent observation and validation receipts. The
[source and check archive](evidence/bootstrap-budget/sources-and-checks.tar.gz)
retains the corresponding artifacts.
'''
assert raw['docs/VALIDATION.md'].split('## Shared startup metadata payloads',1)[1]==before['docs/VALIDATION.md'].split('## Shared startup metadata payloads',1)[1]
assert raw['docs/runtime-budget-boundary.md'].split('This makes the boundary explicit',1)[1]==before['docs/runtime-budget-boundary.md'].split('This makes the boundary explicit',1)[1]
for rel,s in raw.items():
 q=D/'raw'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s)
 q=D/'diffs'/(rel+'.patch');q.parent.mkdir(parents=True,exist_ok=True)
 q.write_text(''.join(difflib.unified_diff(before.get(rel,'').splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
manifest={'status':'draft only; actual validation receipts pending before final seal','published_base':'15226307b153da0857f80486d5f23c375b6b2add','source_review':ref(P/'policy-doc-review-1/source-review.json'),'files':[{'relative':r,'before':ref(D/'before'/r) if r in before else None,'raw':ref(D/'raw'/r),'diff':ref(D/'diffs'/(r+'.patch'))} for r in raw],'preservation':['All preexisting VALIDATION sections are byte-exact.','runtime-budget-boundary original checkpoint text from its second paragraph onward is byte-exact.','All other changes are bounded current-policy summaries; original historical evidence files/chapters unchanged.'],'pending':['Actual accounting observations','Focused/full/strict/release/replay receipts','Final relative evidence-link verification']}
(D/'draft-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('draft',len(raw),'files',sha((D/'draft-manifest.json').read_bytes()))
