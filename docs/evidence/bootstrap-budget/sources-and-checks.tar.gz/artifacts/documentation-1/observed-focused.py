from pathlib import Path
import hashlib,json,re,difflib
P=Path('/tmp/eris-bootstrap-budget-plan-1');D=P/'documentation-1'
def ref(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
records=[]
for n,exitcode in [('parent-control-1',101),('bootstrap-focused-1',0)]:
 j=json.loads((P/'validation'/f'{n}.json').read_text());assert j['exit']==exitcode
 log=P/'validation'/j['log'];assert ref(log)['sha256']==j['sha256'];records.append({'receipt':ref(P/'validation'/f'{n}.json'),'log':ref(log)})
log=(P/'validation/bootstrap-focused-1.log').read_text()
assert 'test result: ok. 53 passed; 0 failed; 0 ignored;' in log
assert 'remaining=900306 allocated=1744317 objects=752 capacity=752 native=299 prototypes=25 globals=212' in log
chapter=D/'raw/docs/bootstrap-budget.md';s=chapter.read_text()
s=s.replace('PENDING_ACCOUNTING','''The Rust 1.88 focused diagnostics observe **99,694 consumed startup units** and
**900,306 remaining** under the new cap. Accounted allocation remains
**1,744,317 bytes**, with 752 objects and capacity, 299 native registry entries,
25 prototype entries and 212 global bindings. Public constructors still return
with exactly 100,000 work units. The additional raw remainder is private test
observability, not an author-accessible allowance.''')
s=s.replace('The published parent\nis expected to fail its first raw-budget assertion; candidate observations are\nrecorded separately below.','The published parent\nfails its first raw-budget assertion after passing the author/heap constants;\nits later exact/oversized admission checks are not reached. The candidate passes\nthis unchanged control.')
s=s.replace('PENDING_VALIDATION_DETAILS','''The focused Rust 1.88 bootstrap run passes **53 tests**, including the new
control and the existing raw/refusal/public-entry witnesses.

PENDING_FINAL_VALIDATION_DETAILS''')
chapter.write_text(s)
summary=D/'raw/docs/VALIDATION.md';s=summary.read_text().replace('PENDING_VALIDATION_SUMMARY','''The new control fails on the published parent at its first raw-budget equality,
after the unchanged author/heap constants pass; later debit checks are unreached.
It passes on the candidate, whose focused bootstrap run passes 53 tests. Raw
diagnostics record 99,694 consumed units and 900,306 remaining, with unchanged
accounted allocation and metadata counts.

PENDING_FINAL_VALIDATION_SUMMARY''');summary.write_text(s)
manifest=json.loads((D/'draft-manifest.json').read_text())
for row in manifest['files']:
 rel=row['relative'];before=(D/'before'/rel).read_text() if row['before'] else ''
 after=(D/'raw'/rel).read_text();diff=D/'diffs'/(rel+'.patch')
 diff.write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
 row['raw']=ref(D/'raw'/rel);row['diff']=ref(diff)
manifest['observed_receipts']=records
manifest['candidate_source']=ref(P/'source-candidate-1.json')
manifest['pending']=['Full Rust/strict/release/replay receipts','Final relative evidence-link verification']
(D/'draft-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(ref(D/'draft-manifest.json'))
