"""Independent inert source/hash review; does not import or run project code."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

P = Path('/tmp/eris-bootstrap-budget-plan-1')
W = Path('/tmp/eris-startup-headroom-plan-1/worktree')
OUT = P / 'html-census-review-1'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}

def read(name):
    return json.loads((P / name).read_text())

seal = read('source-ready.json')
assert sha((P / 'source-ready.json').read_bytes()) == '7f099c936c5b4f076fcecde15cdef08932329c9e4d2abe653bc636cf1be5e89c'
for row in seal['files']:
    actual = bind(Path(row['path']))
    assert all(actual[key] == row[key] for key in ('bytes', 'sha256'))

base = Path(seal['prospective_base']['path'])
assert bind(base) == seal['prospective_base']
inventory = json.loads(base.read_text())['source_sha256']
snapshots = read('source-bindings.json')['files']
for row in snapshots:
    relative = row['relative']
    data = (W / relative).read_bytes()
    assert sha(data) == inventory[relative]
    assert data == Path(row['snapshot']['path']).read_bytes()
    assert bind(Path(row['snapshot']['path'])) == row['snapshot']
assert len(snapshots) == 43

# Read-only Git name enumeration plus the selected untracked source map.
tracked = subprocess.check_output(['git', '-C', str(W), 'ls-files', '-z']).decode().split('\0')
rust_paths = {name for name in tracked if name.endswith('.rs')}
rust_paths |= {name for name in inventory if name.endswith('.rs')}
scan = read('census-scan.json')
assert rust_paths == {row['path'] for row in scan['rust_files']}
assert len(rust_paths) == 583
for row in scan['rust_files']:
    assert sha((W / row['path']).read_bytes()) == row['sha256']

# Independent nearest-declaration ownership; also count every bare spelling to
# ensure the Runtime/Self-qualified call pattern has not missed another form.
fn_pattern = re.compile(r'(?m)^\s*(?:pub(?:\([^\n]*?\))?\s+)?(?:async\s+)?fn\s+(\w+)\s*\(')
call_pattern = re.compile(r'\b(?:Runtime|Self)::uninitialized\s*\(')
found = {}
bare_count = 0
for relative in sorted(rust_paths):
    source = (W / relative).read_text()
    bare_count += len(re.findall(r'\buninitialized\s*\(', source))
    declarations = list(fn_pattern.finditer(source))
    for call in call_pattern.finditer(source):
        declaration = next(item for item in reversed(declarations) if item.start() < call.start())
        key = (relative, declaration.group(1))
        found[key] = found.get(key, 0) + 1
assert sum(found.values()) == 55 and len(found) == 40 and bare_count == 56
groups = read('raw-controls-census.json')['groups']
assert found == {(row['path'], row['function']): row['raw_calls'] for row in groups}
by_group = {(row['path'], row['function']): row for row in groups}
for row in groups:
    source = (W / row['path']).read_text()
    assert row['source'] in source
    assert sha(row['source'].encode()) == row['source_sha256']

migrations = read('migration-census.json')
assert len(migrations['rows']) == 12
assert len({row['path'] for row in migrations['rows']}) == 10
assert {(row['path'], row['group']) for row in migrations['rows']} == {
    key for key, row in by_group.items() if row['classification'] == 'mandatory_migration'
}
changes = []
for row in migrations['rows']:
    current = by_group[(row['path'], row['group'])]['source']
    assert sha(current.encode()) == row['current_group_source_sha256']
    proposed = current
    match_counts = []
    for change in row['changes']:
        match_counts.append(proposed.count(change['before']))
        assert proposed.count(change['before']) >= 1
        proposed = proposed.replace(change['before'], change['after'], 1)
    # Each listed inverse is exact within its function excerpt. No project
    # payload is generated or edited by this check.
    recovered = proposed
    for change in reversed(row['changes']):
        assert recovered.count(change['after']) == 1
        recovered = recovered.replace(change['after'], change['before'], 1)
    assert recovered == current
    changes.append({'path': row['path'], 'group': row['group'], 'replacement_count': len(row['changes']), 'ordered_before_match_counts': match_counts, 'before_sha256': sha(current.encode()), 'proposed_excerpt_sha256': sha(proposed.encode())})

unchanged = migrations['unchanged_explicit_allowances']
assert len(unchanged) == 3
for row in unchanged:
    current = by_group[(row['path'], row['group'])]['source']
    assert sha(current.encode()) == row['source_sha256']
    assert '[(99_693, false, 0), (99_694, true, 0), (100_000, true, 306)]' in current
    assert re.search(r'runtime\.steps = (?:allowance|work);', current)

controls = read('controls-proposed.json')
assert len(controls['new_groups']) == 1
new = controls['new_groups'][0]
assert sha(new['source'].encode()) == new['sha256']
assert 'raw.steps =' not in new['source']
assert 'raw.work(amount)' in new['source'] and 'raw.work(1)' in new['source']
assert 'for amount in [1_000_000usize, 1_000_001]' in new['source']
for row in controls['existing_preservation']:
    source = (W / row['path']).read_text()
    for group in row['groups']:
        assert re.search(r'\bfn\s+' + re.escape(group) + r'\s*\(', source)

# Supporting glob-import chains establish that the new private constant will
# be visible to the selected existing descendant test modules.
parents = ['array_buffer.rs', 'array_buffer/bootstrap.rs', 'data_view.rs', 'dom_bindings.rs', 'dom_prototypes.rs', 'object_is.rs', 'processing_instruction.rs', 'test262_host.rs', 'typed_array.rs', 'typed_array/intrinsics.rs']
parent_bindings = []
for relative in parents:
    path = W / 'src/script' / relative
    assert 'use super::*;' in path.read_text()
    assert sha(path.read_bytes()) == inventory['src/script/' + relative]
    parent_bindings.append(bind(path))

report = {
    'status': 'clear',
    'scope': 'Independent source-only migration census and proposed bound-control review. This is not an executable test hold, implementation approval, or observed outcome.',
    'proposal': bind(P / 'source-ready.json'),
    'base': bind(base),
    'prior_public_entry_review': bind(P / 'public-entry-audit-1/review.json'),
    'verified_counts': {'manifest_payloads': len(seal['files']), 'source_snapshots': 43, 'rust_paths': 583, 'raw_calls': 55, 'owning_functions': 40, 'mandatory_files': 10, 'mandatory_groups': 12, 'literal_replacements': sum(x['replacement_count'] for x in changes), 'preserved_injected_allowance_groups': 3, 'new_control_groups': 1},
    'migrations': changes,
    'source_assessment': [
        'Five raw-initialization diagnostics compare remaining work against the startup origin; their upper bound must become BOOTSTRAP_STEPS. Positive remaining, heap, identities and public-reset controls remain unchanged.',
        'The metadata-slot admission test starts uninitialized, calls alloc_native and preserves work; its unchanged-counter assertion must use the raw initial allowance.',
        'The initial reserve-heap refusal consumes exactly one work unit; the late-work test derives startup consumption from its raw origin; the convenience test alone changes raw remainder. All failure stages and public MAX_STEPS assertions remain.',
        'The PI diagnostic and assertion both subtract the startup origin, retaining literal consumed99694. The typed cumulative expression appends only900000; old installation and heap terms remain exact. The inactive host test changes only raw remaining, preserving author100000/heap8MiB and absent session/print/DONE.',
        'The PI first replacement fragment occurs twice within its original function: the print argument and the later assertion. Ordered first-occurrence replacement selects the print argument; the following whole-assertion replacement selects the second site. The executable hold should preserve that exact two-site result rather than assume each original fragment is globally unique.',
        'The three99693/99694/100000 matrices explicitly overwrite raw steps; retain every row, including remaining306. Other raw helpers either use positive-only observations, derive consumption from a saved initial value, or explicitly reset fixture counters.',
        'The only production raw caller is try_new. Its successful initialization reset remains MAX_STEPS; errors propagate before that reset. Earlier independent public-entry review covers date-host, adapter, author event and audit boundaries.'
    ],
    'new_control_assessment': [
        'The proposed group uses existing private parent APIs and no new symbol. Its first raw.steps assertion intentionally fails against parent100000; later rows must not be reported as observed on that parent run.',
        'work admits exactly1000000, subtracts to zero, and then refuses1. A fresh raw state refuses1000001, sets zero and returns ResourceLimit. No counter reset occurs in the source.',
        'work does not alter allocated, objects, native_properties or frames. The proposed state assertions match actual helper behavior; they do not assert unrelated sticky suspension.',
        'Existing public constructor, explicit initialization boundary, early-heap-refusal, nested author and host-final controls detect leaking or resetting the new allowance. No additional broad control family is needed for the stated two-site production scope.'
    ],
    'arithmetic': {'unchanged_consumed_work': 99694, 'old_raw_remaining': 306, 'proposed_raw_remaining': 1000000 - 99694, 'public_remaining': 100000, 'heap_delta': 0},
    'parent_import_visibility_bindings': parent_bindings,
    'qualifications': [
        'The seal retains its prospective unpublished-base wording. Publication refresh and executable tests/migrations remain root-selected next steps; this receipt does not rewrite the sealed history.',
        '35 scanned Rust paths outside the selected inventory are historical/tool sources, not asserted to be selected compile inputs. All raw-call ownership was independently matched.',
        'Only read-only Git names and inert standard-library source/hash processing were used. No project modules, tests, compilers, engines or proposal authoring scripts were executed. No live or startup-sharing artifacts were written.'
    ],
    'findings': [],
    'reviewer_script': bind(Path(__file__))
}
OUT.mkdir(exist_ok=True)
(OUT / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(bind(OUT / 'review.json')))
