from pathlib import Path
import json,hashlib,re
P=Path('/tmp/eris-bootstrap-budget-plan-1'); W=P/'worktree'; O=P/'policy-doc-review-1'
def sha(b):return hashlib.sha256(b).hexdigest()
def base(rel):
 p=P/'source-snapshots'/rel
 return p if p.exists() else W/rel
def ref(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def save(n,j):
 p=O/n;p.write_text(json.dumps(j,indent=2)+'\n');print(n,sha(p.read_bytes()))
parent=json.loads((P/'source-parent.json').read_text());assert parent['base']=='15226307b153da0857f80486d5f23c375b6b2add'
selection=json.loads((P/'root/selection-1.json').read_text());assert selection['published_base']==parent['base']
proposal=json.loads((P/'source-ready.json').read_text())
assert sha((P/'source-ready.json').read_bytes())==selection['proposal']['sha256']
snaps=[]
for r in proposal['files']:
 p=Path(r['path']);assert len(p.read_bytes())==r['bytes'] and sha(p.read_bytes())==r['sha256']
 if r['relative'].startswith('source-snapshots/'):
  rel=r['relative'].removeprefix('source-snapshots/');assert parent['source_sha256'][rel]==r['sha256'];snaps.append(rel)
assert len(snaps)==43
census=json.loads((P/'raw-controls-census.json').read_text())
for g in census['groups']:
 assert g['source'] in base(g['path']).read_text(),(g['path'],g['function'])
 assert sha(g['source'].encode())==g['source_sha256']
raw=[]
for rel in parent['source_sha256']:
 if not rel.endswith('.rs'):continue
 p=base(rel)
 assert sha(p.read_bytes())==parent['source_sha256'][rel]
 for i,line in enumerate(p.read_text().splitlines(),1):
  if re.search(r'\b(?:Self|Runtime)::uninitialized\s*\(',line):raw.append({'path':rel,'line':i,'source':line.strip()})
assert len(raw)==55 and sum(g['raw_calls'] for g in census['groups'])==55
assert len(census['groups'])==40
assert [g['function'] for g in census['groups'] if g['classification']=='production_entry_only']==['try_new']
script=base('src/script.rs').read_text()
assert 'runtime.initialize_bootstrap()?;\n        runtime.steps = MAX_STEPS;\n        Ok(runtime)' in script
assert '#[cfg(test)]\n    fn finish_bootstrap' in script
assert 'started: std::time::Instant::now(),' in script
assert 'const MAX_STEPS: usize = 100_000;' in script and 'const MAX_HEAP: usize = 8 * 1024 * 1024;' in script
files=['src/script.rs','src/page.rs','src/worker.rs','src/date_host.rs','src/bin/eris-js.rs','src/bin/eris-js/test262_host.rs','src/bin/eris-stress.rs','src/script/microtasks.rs','src/script/test262_host.rs','src/script/parser.rs','src/script/code.rs']
inputs=[]
for rel in files:
 r=ref(base(rel));assert parent['source_sha256'][rel]==r['sha256'];inputs.append({'relative':rel,**r})
docs=['README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','docs/SECURITY.md','docs/runtime-budget-boundary.md','docs/VALIDATION.md','docs/runtime-initialization.md','docs/ARCHITECTURE.md','docs/startup-metadata-sharing.md']
for rel in docs:inputs.append({'relative':rel,**ref(base(rel))})
save('selection-wording-correction.json',{
 'status':'source-only wording qualification; selection1 preserved byte-for-byte',
 'original_selection':ref(P/'root/selection-1.json'),
 'original_rationale':selection['rationale'],
 'finding':'The phrase no host reads is too broad: Runtime::uninitialized records std::time::Instant::now() before installation. It does not sample the supplied Date clock/timezone, read document input or invoke author callbacks.',
 'source':{'path':'src/script.rs','line':1776,'text':'started: std::time::Instant::now(),','binding':ref(base('src/script.rs'))},
 'corrected_rationale':'Trusted intrinsic installation uses fixed compiled metadata, with no author callbacks or document input and no Date clock/timezone discovery. Runtime construction retains its existing monotonic start timestamp. The separate finite initialization cap changes no author-entry allowance, operation charge or cumulative heap limit.',
 'effect':'Wording only; selected constants, production sites, control expectations and admission/reset order are unchanged. No claim that startup performs zero host reads or bounds total CPU/RSS.'})
save('source-review.json',{
 'status':'clear',
 'scope':'Independent source-only selected-policy/public-entry/documentation review; no compiler, engine, project code, Git, browser or live-source execution/edits.',
 'published_base':parent['base'],'parent_inventory':ref(P/'source-parent.json'),
 'selected_proposal':ref(P/'source-ready.json'),'selection':ref(P/'root/selection-1.json'),
 'baseline_read_method':'43 proposal snapshots are joined directly to the published parent inventory; other unchanged inputs are hash-joined to that inventory. Concurrent candidate imports are not mistaken for the published base.',
 'checked_proposal_snapshots':len(snaps),'raw_calls':len(raw),'raw_owning_functions':40,
 'inputs':inputs,
 'selected_boundary':{'trusted_initialization_work':1000000,'author_entry_work':100000,'cumulative_accounted_heap':8388608,'source_derived_consumed_startup':99694,'prospective_raw_remaining':900306,'public_success_remaining':100000,'qualification':'New-policy remaining values are source-derived, not candidate run results. Current published raw remainder remains306.'},
 'public_entry_proof':[
  {'source':'src/script.rs:1565,1597,1612-1638,1827-1857','fact':'Runtime fields and raw initializer are private; only try_new is a production raw caller. initialize_bootstrap? must succeed before MAX_STEPS reset and Ok(runtime). Default/new and both Date-host constructors delegate through that boundary. cfg(test) finish_bootstrap intentionally exposes raw state only in tests.'},
  {'source':'src/script.rs:1827-1835,1869-1876; src/date_host.rs:58-64','fact':'Installation reserves objects/frames and installs fixed intrinsic metadata. No document or author callback is provided. Supplied DateHost is assigned after try_new, so its clock/zone cannot consume bootstrap work.'},
  {'source':'src/page.rs:449-510,650-665; src/bin/eris-stress.rs:688','fact':'Page and error-page paths obtain a completed Runtime through try_with_date_host before scripts; stress uses try_new. A checked failure publishes no partial realm or fallback larger author budget.'},
  {'source':'src/script.rs:2378-2413,3457-3580','fact':'Script entries, first readiness dispatch, details task batches and valid host event entries retain their MAX_STEPS resets. Parsing/storage/preflight errors can precede reset; this does not expose raw work because every public Runtime was already normalized. Nested synthetic callbacks do not enter these host reset sites.'},
  {'source':'src/script/microtasks.rs:190-201,266-343','fact':'Author-entry and checkpoint helpers only debit current steps; they never replenish. Fatal suspension remains sticky through later ordinary resets.'},
  {'source':'src/bin/eris-js.rs:241-310; src/bin/eris-js/test262_host.rs:197-278; src/script/test262_host.rs:219-368,484-519','fact':'Adapters preparse before runtime construction. Test262 host installation occurs after normalized construction; setup/bind/arm debit current work. Harness/body use ordinary100000 execute entries; the final audit spends body remainder with no fresh grant. Authentication, phase/error policy and denominators are outside this proposal.'},
  {'source':'src/script.rs:3610-3633; src/script/parser.rs:68; src/script.rs:7234,7820,7843','fact':'Existing checked work subtraction and cumulative heap charge remain. Standalone parser budgets retain MAX_STEPS; dynamic compilation receives current author remainder. No bootstrap constant belongs in parser, callback, host or final-audit paths.'}
 ],
 'documentation_actions':[
  {'path':'docs/SECURITY.md','lines':[326,347,349],'action':'Required current-policy correction: identify1000000 trusted initialization separately from100000 author entries, success-only normalization and shared cumulative8MiB. The initialization allowance increases; do not describe all quotas as unchanged. Keep ordinary script, callback, notification, storage and process-limit rows exact.'},
  {'path':'docs/runtime-budget-boundary.md','lines':[3,7,14],'action':'Required opening-policy correction and forward link. Preserve historical checkpoint metrics/results from line16 onward; the original same-sized allowances remain historical evidence.'},
  {'path':'README.md','lines':[63,65],'action':'Qualify306 as the previous metadata checkpoint; add concise current trusted1000000/author100000/shared8MiB boundary link. Prior key-sharing savings remain valid.'},
  {'path':'docs/ROADMAP.md','lines':[46,48],'action':'Qualify historical306 and identify separate trusted cap. It creates policy headroom, not implementation or measured admission for any/AggregateError.'},
  {'path':'docs/COMPATIBILITY.md','lines':[57,59],'action':'Add boundary link with no API/conformance gain or inferred new upstream passes; current startup-sharing claims remain valid.'},
  {'path':'docs/VALIDATION.md','lines':[3,29],'action':'Add a new checkpoint section using actual receipts only; preserve existing shared-metadata section and all historical measurements byte-for-byte.'},
  {'path':'docs/bootstrap-budget.md','action':'New concise mechanism/limitations/evidence chapter: selected finite cap, exact reset/error order, cumulative heap, no fee/layout/ID changes, qualified raw diagnostics and later observed validation.'}
 ],
 'historical_or_unchanged_docs':[
  {'path':'docs/startup-metadata-sharing.md','reason':'Published checkpoint measured99,694/306 under100000; retain its numbers, old failure history and archive.'},
  {'path':'docs/runtime-initialization.md','reason':'Original-checkpoint numbers already explicitly historical; existing failure routing and success-only author grant stay correct. Optional forward link only, not required numeric replacement.'},
  {'path':'docs/ARCHITECTURE.md:80-103','reason':'100000 details-task cap and shared microtask remainder remain current and unchanged.'},
  {'paths':['docs/node-data.md','docs/node-normalize.md','docs/text-operations.md','docs/promise-foundation.md','docs/promise-catch.md','docs/promise-finally.md','docs/promise-race.md','docs/promise-all-settled.md','docs/node-accessor-keys.md','docs/node-method-keys.md','docs/text-metadata-keys.md'],'reason':'Checkpoint resource statements remain historical; do not silently rewrite their cap/remainder observations or evidence.'}
 ],
 'selection_wording_correction':ref(O/'selection-wording-correction.json'),
 'non_blocking_findings':['Replace overly broad no host reads rationale with the bound correction; retained monotonic timestamp is not an author-budget exposure.'],
 'preservation_obligations':['Keep all explicit99693/99694/100000 raw test matrices and exact operation/heap cuts.','Keep all public MAX_STEPS/reset assertions, error paths, sticky suspension, Date-sample witnesses, setup and final-audit charges.','Treat raising the trusted cap as a policy change, not reduced work, runtime optimization, complete allocation accounting, broader security or future combinator admission.'],
 'execution':'None; read/hash/stdlib artifact writing only.'})
